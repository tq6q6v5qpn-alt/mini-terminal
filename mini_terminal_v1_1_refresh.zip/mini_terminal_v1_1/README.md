# Mini Bloomberg-like Canary Terminal (V1.1)

Ready-to-run 5-minute crypto+macro monitor.
